# generate_reports.py
import mysql.connector
import pandas as pd
import plotly.express as px
import plotly.offline as pyo
import os
from datetime import datetime
#  Connect to MySQL
conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="root",
    database="farmer"
)
cursor = conn.cursor()

#  Calculate Total Orders (Only Placed & Delivered)

cursor.execute("""
SELECT COUNT(*) 
FROM orders 
WHERE status IN ('placed', 'delivered','shipped')
""")
total_orders = cursor.fetchone()[0]

#  Calculate Total Revenue (Exclude Cancelled & Returned)

cursor.execute("""
SELECT SUM(oi.price * oi.quantity)
FROM order_items oi
JOIN orders o ON oi.order_id = o.oid
WHERE o.status IN ('placed', 'delivered')
""")
total_revenue = cursor.fetchone()[0] or 0.0

#  Determine Top Product (Only Valid Orders)

cursor.execute("""
SELECT p.product_name, SUM(oi.quantity) AS sold_count
FROM order_items oi
JOIN orders o ON oi.order_id = o.oid
JOIN addproduct p ON oi.product_id = p.id
WHERE o.status IN ('placed', 'delivered')
GROUP BY oi.product_id
ORDER BY sold_count DESC
LIMIT 1
""")
top_product_row = cursor.fetchone()
top_product = top_product_row[0] if top_product_row else "-"

#  Determine Top Farmer (Only Valid Orders)

cursor.execute("""
SELECT f.name, SUM(oi.quantity) AS sold_count
FROM order_items oi
JOIN orders o ON oi.order_id = o.oid
JOIN addproduct p ON oi.product_id = p.id
JOIN farmer f ON p.email = f.email
WHERE o.status IN ('placed', 'delivered')
GROUP BY f.email
ORDER BY sold_count DESC
LIMIT 1
""")
top_farmer_row = cursor.fetchone()
top_farmer = top_farmer_row[0] if top_farmer_row else "-"

#  Insert into admin_reports

cursor.execute("DELETE FROM admin_reports")
cursor.execute("""
INSERT INTO admin_reports (total_orders, total_revenue, top_product, top_farmer)
VALUES (%s,%s,%s,%s)
""", (total_orders, total_revenue, top_product, top_farmer))
conn.commit()

#  Set custom folder for charts

charts_dir = r"C:\Users\yuvas\OneDrive\Desktop\editpro\Farmer (2)\Farmer\web\static"
os.makedirs(charts_dir, exist_ok=True)

#  Generate Monthly Sales Chart (Only Valid Orders)

monthly_sales = pd.read_sql("""
SELECT DATE_FORMAT(o.order_date, '%Y-%m') AS month, 
       SUM(oi.price * oi.quantity) AS revenue
FROM orders o
JOIN order_items oi ON oi.order_id = o.oid
WHERE o.status IN ('placed', 'delivered', 'shipped')
GROUP BY month
ORDER BY month
""", conn)

fig_sales = px.bar(
    monthly_sales,
    x='month',
    y='revenue',
    title='Monthly Sales (Placed & Delivered Only)',
    labels={'month': 'Month', 'revenue': 'Revenue'},
    text='revenue'
)

fig_sales.update_layout(xaxis_tickangle=-45)

pyo.plot(
    fig_sales,
    filename=os.path.join(charts_dir, 'monthly_sales.html'),
    auto_open=False
)
#  Generate Top 5 Products Pie Chart (Only Valid Orders)
top_products = pd.read_sql("""
SELECT p.product_name, SUM(oi.quantity) AS sold_count
FROM order_items oi
JOIN orders o ON oi.order_id = o.oid
JOIN addproduct p ON oi.product_id = p.id
WHERE o.status IN ('placed', 'delivered', 'shipped')
GROUP BY oi.product_id
ORDER BY sold_count DESC
LIMIT 5
""", conn)

fig_top = px.pie(
    top_products,
    names='product_name',
    values='sold_count',
    title='Top 5 Products Sold '
)

pyo.plot(
    fig_top,
    filename=os.path.join(charts_dir, 'top_products.html'),
    auto_open=False
)
#  Close connection

cursor.close()
conn.close()

print(" Admin report updated successfully!")
print(f"Total Orders: {total_orders}")
print(f"Total Revenue: ₹{total_revenue:.2f}")
print(f"Top Product: {top_product}")
print(f"Top Farmer: {top_farmer}")
print(f"Charts generated in:")
print(f" - {charts_dir}\\monthly_sales.html")
print(f" - {charts_dir}\\top_products.html")
