import mysql.connector
import pandas as pd
import plotly.express as px
import plotly.offline as pyo
import os
from datetime import date
#  ENTER SELLER EMAIL HERE
seller_email = "farmer1@gmail.com"   # make dynamic later
#  CONNECT TO DATABASE
conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="root",
    database="farmer"
)

cursor = conn.cursor()
#  TOTAL ORDERS
cursor.execute("""
SELECT COUNT(DISTINCT o.oid)
FROM orders o
JOIN order_items oi ON o.oid = oi.order_id
JOIN addproduct p ON oi.product_id = p.id
WHERE o.status IN ('placed','delivered')
AND p.email = %s
""", (seller_email,))
total_orders = cursor.fetchone()[0]
#  TOTAL REVENUE
cursor.execute("""
SELECT SUM(oi.price * oi.quantity)
FROM orders o
JOIN order_items oi ON o.oid = oi.order_id
JOIN addproduct p ON oi.product_id = p.id
WHERE o.status IN ('placed','delivered')
AND p.email = %s
""", (seller_email,))
total_revenue = cursor.fetchone()[0] or 0.0
#  TOP PRODUCT
cursor.execute("""
SELECT p.product_name, SUM(oi.quantity) AS sold_count
FROM orders o
JOIN order_items oi ON o.oid = oi.order_id
JOIN addproduct p ON oi.product_id = p.id
WHERE o.status IN ('placed','delivered')
AND p.email = %s
GROUP BY oi.product_id
ORDER BY sold_count DESC
LIMIT 1
""", (seller_email,))

row = cursor.fetchone()
top_product = row[0] if row else "-"
#  QUALITY RETURN COUNT
cursor.execute("""
SELECT COUNT(*)
FROM returns r
JOIN addproduct p ON r.product_id = p.id
WHERE p.email = %s
AND r.reason = 'Not Good Quality'
""", (seller_email,))
quality_returns = cursor.fetchone()[0]

#  AUTO WARNING / BLOCK LOGIC

if quality_returns >= 7:
    cursor.execute("""
    UPDATE farmer
    SET status='Blocked',
        block_until=DATE_ADD(CURDATE(), INTERVAL 7 DAY)
    WHERE email=%s
    """, (seller_email,))
elif quality_returns >= 4:
    cursor.execute("""
    UPDATE farmer
    SET status='Warning',
        warning_count = warning_count + 1
    WHERE email=%s
    """, (seller_email,))

conn.commit()

#  CREATE CHART FOLDER
charts_dir = r"C:\Users\yuvas\OneDrive\Desktop\editpro\Farmer (2)\Farmer\web\static\seller_reports"
os.makedirs(charts_dir, exist_ok=True)
#  MONTHLY SALES CHART
monthly_sales = pd.read_sql("""
SELECT DATE_FORMAT(o.order_date, '%Y-%m') AS month,
       SUM(oi.price * oi.quantity) AS revenue
FROM orders o
JOIN order_items oi ON o.oid = oi.order_id
JOIN addproduct p ON oi.product_id = p.id
WHERE o.status IN ('placed','delivered')
AND p.email = %s
GROUP BY month
ORDER BY month
""", conn, params=[seller_email])

fig_sales = px.bar(
    monthly_sales,
    x='month',
    y='revenue',
    title='Seller Monthly Sales',
    text='revenue'
)

fig_sales.update_layout(xaxis_tickangle=-45)

pyo.plot(
    fig_sales,
    filename=os.path.join(charts_dir, 'monthly1_sales.html'),
    auto_open=False
)

#  PRODUCT PERFORMANCE CHART
product_sales = pd.read_sql("""
SELECT p.product_name, SUM(oi.quantity) AS sold_count
FROM orders o
JOIN order_items oi ON o.oid = oi.order_id
JOIN addproduct p ON oi.product_id = p.id
WHERE o.status IN ('placed','delivered')
AND p.email = %s
GROUP BY oi.product_id
ORDER BY sold_count DESC
""", conn, params=[seller_email])

fig_products = px.pie(
    product_sales,
    names='product_name',
    values='sold_count',
    title='Product Performance'
)

pyo.plot(
    fig_products,
    filename=os.path.join(charts_dir, 'product_performance.html'),
    auto_open=False
)


#  CLOSE CONNECTION

cursor.close()
conn.close()

print("Seller Report Generated Successfully!")
print("Total Orders:", total_orders)
print("Total Revenue: ₹", total_revenue)
print("Top Product:", top_product)
print("Quality Returns:", quality_returns)
