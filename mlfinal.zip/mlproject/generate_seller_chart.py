import mysql.connector
import matplotlib.pyplot as plt

def generate_sales_chart(farmer_id):
    try:
        # MySQL Connection
        conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password="root",
            database="farmer"
        )

        cursor = conn.cursor()

        # Fetch product-wise sales
        cursor.execute("""
            SELECT p.product_name, SUM(oi.quantity) as total_sold
            FROM order_items oi
            JOIN products p ON oi.product_id = p.id
            WHERE p.farmer_id = %s
            GROUP BY p.product_name
        """, (farmer_id,))

        data = cursor.fetchall()

        if not data:
            print("No sales data found for this farmer.")
            return

        products = [row[0] for row in data]
        quantities = [row[1] for row in data]

        # Create chart
        plt.figure()
        plt.bar(products, quantities)
        plt.xlabel("Products")
        plt.ylabel("Quantity Sold")
        plt.title("Product-wise Sales Report")
        plt.xticks(rotation=45)
        plt.tight_layout()

        # Save image
        chart_path = f"seller_chart_{farmer_id}.png"
        plt.savefig(chart_path)

        print("Chart generated successfully:", chart_path)

        cursor.close()
        conn.close()

    except mysql.connector.Error as err:
        print("Database Error:", err)


# Example run
if __name__ == "__main__":
    farmer_id = int(input("Enter Farmer ID: "))
    generate_sales_chart(farmer_id)
