import sys
import mysql.connector
import matplotlib.pyplot as plt
import os
import re

# -----------------------------
# 1️⃣ Get farmer email safely
# -----------------------------
if len(sys.argv) < 2:
    print("Error: No farmer email provided!")
    sys.exit(1)

farmer_email = sys.argv[1]
print(f"Generating chart for farmer: {farmer_email}")

# -----------------------------
# 2️⃣ Connect to database
# -----------------------------
try:
    conn = mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database="farmer"
    )
except mysql.connector.Error as e:
    print(f"Database connection error: {e}")
    sys.exit(1)

cursor = conn.cursor()

# -----------------------------
# 3️⃣ Fetch product sales for this farmer
# -----------------------------
query = """
SELECT p.product_name, IFNULL(SUM(oi.quantity),0) AS total_quantity
FROM addproduct p
LEFT JOIN order_items oi ON p.id = oi.product_id
WHERE p.email = %s
GROUP BY p.product_name
"""

cursor.execute(query, (farmer_email,))
data = cursor.fetchall()

if not data:
    print("No products found for this farmer!")
    products = []
    quantities = []
else:
    products = [row[0] for row in data]
    quantities = [row[1] for row in data]

# Close DB connection
cursor.close()
conn.close()

# -----------------------------
# 4️⃣ Generate unique chart filename
# -----------------------------
# Remove invalid filename characters from email
safe_email = re.sub(r'[^\w\-_\.]', '_', farmer_email)
save_path = fr"C:\Users\yuvas\OneDrive\Desktop\editpro\Farmer (2)\Farmer\web\static\farmer_{safe_email}.png"

# -----------------------------
# 5️⃣ Generate chart
# -----------------------------
if products:  # Only generate if products exist
    plt.figure(figsize=(8,5))
    plt.bar(products, quantities, color='skyblue')
    plt.xticks(rotation=45, ha='right')
    plt.xlabel("Product Name")
    plt.ylabel("Total Sold Quantity")
    plt.title(f"Sales Report for {farmer_email}")
    plt.tight_layout()

    plt.savefig(save_path)
    plt.close()
    print(f"Chart generated successfully: {save_path}")
else:
    print("No data to plot. Chart not generated.")
