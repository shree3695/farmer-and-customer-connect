import mysql.connector
import pandas as pd
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity

# Connect to MySQL

conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="root",
    database="farmer"
)
cursor = conn.cursor()

# Fetch user-product-quantity data

query = """
SELECT o.user_id AS user, p.id AS product_id, 
       p.product_name AS product, oi.quantity
FROM orders o
JOIN order_items oi ON o.oid = oi.order_id
JOIN addproduct p ON oi.product_id = p.id
WHERE o.status IN ('Placed', 'Delivered','shipped')
"""
orders = pd.read_sql(query, conn)

print("User-Product Orders:\n", orders.head())


# Fetch all products (for fallback)

all_products_query = "SELECT id, product_name FROM addproduct"
all_products = pd.read_sql(all_products_query, conn)

# Fallback: Top Selling Products

def top_selling_products(top_n=4):
    if not orders.empty:
        top_products = (
            orders.groupby(['product', 'product_id'])['quantity']
            .sum()
            .sort_values(ascending=False)
            .reset_index()
        )
        return top_products.head(top_n).values.tolist()
    else:
        # If no orders exist → recommend random products
        return all_products.head(top_n).values.tolist()



# If no orders exist at all

if orders.empty:
    print("No order data available. Using fallback for all users.")

    cursor.execute("DELETE FROM user_recommendations WHERE type=0")
    conn.commit()

    cursor.execute("SELECT id FROM customer_register")
    users = cursor.fetchall()

    for user in users:
        user_id = user[0]
        fallback_products = top_selling_products(4)

        for prod in fallback_products:
            product_id = int(prod[0])
            cursor.execute(
                """
                INSERT IGNORE INTO user_recommendations
                (uid, product_id, score, type)
                VALUES (%s,%s,%s,%s)
                """,
                (user_id, product_id, 1.0, 0)
            )

    conn.commit()

else:

   
    # Create User-Item Matrix
    
    user_item_matrix = orders.pivot_table(
        index='user',
        columns='product',
        values='quantity',
        aggfunc='sum',
        fill_value=0
    )

    user_item_matrix_norm = user_item_matrix.div(
        user_item_matrix.max(axis=1),
        axis=0
    ).fillna(0)

    product_matrix = user_item_matrix_norm.T

    similarity = pd.DataFrame(
        cosine_similarity(product_matrix),
        index=product_matrix.index,
        columns=product_matrix.index
    )


    # Recommendation Function
   
    def recommend_products(user_id, top_n=4):

        if user_id not in user_item_matrix_norm.index:
            return top_selling_products(top_n)

        user_ratings = user_item_matrix_norm.loc[user_id]
        purchased = user_ratings[user_ratings > 0].index.tolist()

        scores = {}

        for product in user_item_matrix_norm.columns:
            if product in purchased:
                continue

            sim_scores = similarity.loc[product, purchased]
            scores[product] = (sim_scores * user_ratings[purchased]).sum()

        recommended = sorted(
            scores.items(),
            key=lambda x: x[1],
            reverse=True
        )

        # If ML score empty → fallback
        if not recommended or recommended[0][1] == 0:
            return top_selling_products(top_n)

        return recommended[:top_n]


    # Clear old ML recommendations
  
    cursor.execute("DELETE FROM user_recommendations WHERE type=0")
    conn.commit()

  
    # Generate ML-based recommendations
 
    for user_id in user_item_matrix_norm.index:
        recs = recommend_products(user_id, top_n=4)

        for rec in recs:

            if isinstance(rec, list) or isinstance(rec, np.ndarray):
                product_id = int(rec[1])
                score = 1.0
            else:
                product_name, score = rec
                product_id = int(
                    orders[orders['product'] == product_name]
                    ['product_id'].iloc[0]
                )

            cursor.execute(
                """
                INSERT IGNORE INTO user_recommendations
                (uid, product_id, score, type)
                VALUES (%s,%s,%s,%s)
                """,
                (int(user_id), product_id, float(score), 0)
            )

    conn.commit()


# Location-Based Recommendation

cursor.execute("DELETE FROM user_recommendations WHERE type=1")
conn.commit()

query_users = "SELECT id, location FROM customer_register"
users_df = pd.read_sql(query_users, conn)

query_products = """
SELECT p.id AS product_id, 
       p.product_name, 
       f.location AS farmer_location
FROM addproduct p
JOIN farmer f ON p.email = f.email
"""
products_df = pd.read_sql(query_products, conn)

for idx, row in users_df.iterrows():
    user_id = row['id']
    user_loc = row['location']

    loc_products = products_df[
    products_df['farmer_location'].str.lower().str.strip() ==
    str(user_loc).lower().strip()
]
    for _, prod in loc_products.iterrows():
        cursor.execute(
            """
            INSERT IGNORE INTO user_recommendations
            (uid, product_id, score, type)
            VALUES (%s,%s,%s,%s)
            """,
            (int(user_id), int(prod['product_id']), 1.0, 1)
        )
        # Ensure every user has at least 4 ML recommendations
cursor.execute("SELECT id FROM customer_register")
all_users = cursor.fetchall()

for user in all_users:
    user_id = user[0]

    cursor.execute("""
        SELECT COUNT(*) FROM user_recommendations
        WHERE uid=%s AND type=0
    """, (user_id,))
    
    count = cursor.fetchone()[0]

    if count == 0:
        fallback_products = top_selling_products(4)
        for prod in fallback_products:
            product_id = int(prod[1]) if len(prod) > 1 else int(prod[0])
            cursor.execute("""
                INSERT IGNORE INTO user_recommendations
                (uid, product_id, score, type)
                VALUES (%s,%s,%s,%s)
            """, (user_id, product_id, 1.0, 0))




conn.commit()

print("\nRecommendations inserted successfully.")


# Close Connection

conn.close()
