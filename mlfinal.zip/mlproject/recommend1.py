import mysql.connector
import pandas as pd
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity

# -------------------------
# Connect to MySQL
# -------------------------
conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="root",
    database="farmer"
)
cursor = conn.cursor()

# -------------------------
# Fetch user-product-quantity data for ML-based
# -------------------------
query = """
SELECT o.user_id AS user, p.id AS product_id, p.product_name AS product, oi.quantity
FROM orders o
JOIN order_items oi ON o.oid = oi.order_id
JOIN addproduct p ON oi.product_id = p.id
WHERE o.status IN ('Placed', 'Delivered')
"""
orders = pd.read_sql(query, conn)
print("User-Product Orders:\n", orders.head())


# -------------------------
#  Create user-item matrix
# -------------------------
user_item_matrix = orders.pivot_table(
    index='user',
    columns='product',
    values='quantity',
    aggfunc='sum',
    fill_value=0
)
print("\nUser-Item Matrix:\n", user_item_matrix)

# -------------------------
# Normalize quantities per user (0–1)
# -------------------------
user_item_matrix_norm = user_item_matrix.div(user_item_matrix.max(axis=1), axis=0).fillna(0)

# -------------------------
#  Compute product similarity
# -------------------------
product_matrix = user_item_matrix_norm.T
similarity = pd.DataFrame(
    cosine_similarity(product_matrix),
    index=product_matrix.index,
    columns=product_matrix.index
)

# -------------------------
#  Recommendation function (weighted)
# -------------------------
def recommend_products(user_id, top_n=4):
    if user_id not in user_item_matrix_norm.index:
        return []
    
    user_ratings = user_item_matrix_norm.loc[user_id]
    purchased = user_ratings[user_ratings > 0].index.tolist()
    
    scores = {}
    for product in user_item_matrix_norm.columns:
        if product in purchased:
            continue
        sim_scores = similarity.loc[product, purchased]
        scores[product] = (sim_scores * user_ratings[purchased]).sum()
    
    recommended = sorted(scores.items(), key=lambda x: x[1], reverse=True)
    return recommended[:top_n]

# -------------------------
# Clear old recommendations
# -------------------------
cursor.execute("DELETE FROM user_recommendations")
conn.commit()

# -------------------------
# Generate & insert ML-based recommendations
# -------------------------
for user_id in user_item_matrix_norm.index:
    recs = recommend_products(user_id, top_n=4)
    for product_name, score in recs:
        # Get product_id from orders DataFrame
        product_id = int(orders[orders['product'] == product_name]['product_id'].iloc[0])
        cursor.execute(
            "INSERT IGNORE INTO user_recommendations (uid, product_id, score, type) VALUES (%s,%s,%s,%s)",
            (int(user_id), product_id, float(score), 0)  # type=0 = ML-based
        )

# -------------------------
# Location-based recommendations
# -------------------------
# Get users and their location
query_users = "SELECT id, location FROM customer_register"
users_df = pd.read_sql(query_users, conn)

# Get all products with farmer locations
query_products = """
SELECT p.id AS product_id, p.product_name, f.location AS farmer_location
FROM addproduct p
JOIN farmer f ON p.email = f.email
"""
products_df = pd.read_sql(query_products, conn)

for idx, row in users_df.iterrows():
    user_id = row['id']
    user_loc = row['location']
    
    # Filter products from the same location
    loc_products = products_df[products_df['farmer_location'] == user_loc]
    
    for _, prod in loc_products.iterrows():
        cursor.execute(
            "INSERT IGNORE INTO user_recommendations (uid, product_id, score, type) VALUES (%s,%s,%s,%s)",
            (int(user_id), int(prod['product_id']), 1.0, 1)  # type=1 = location-based
        )

conn.commit()

# -------------------------
# Print top ML recommendations for verification
# -------------------------
for user_id in user_item_matrix_norm.index:
    recs = recommend_products(user_id, top_n=4)
    print(f"\nTop ML recommendations for User {user_id}:")
    if not recs:
        print("  No ML recommendations available.")
    else:
        for product, score in recs:
            print(f"  {product}: {score:.2f}")

print("\nLocation-based recommendations inserted successfully.")

# -------------------------
#  Close connection
# -------------------------
conn.close()
