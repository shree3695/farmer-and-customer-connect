import mysql.connector
import matplotlib.pyplot as plt
import re
import os

conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="root",
    database="farmer"
)
cursor = conn.cursor()

# Create summary table (original structure)
cursor.execute("""
CREATE TABLE IF NOT EXISTS farmer_sales_summary (
    email VARCHAR(255) PRIMARY KEY,
    total_orders INT DEFAULT 0,
    total_revenue DOUBLE DEFAULT 0,
    total_returned_orders INT DEFAULT 0,
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)
""")

# Get all farmers
cursor.execute("SELECT DISTINCT email FROM addproduct")
farmers = cursor.fetchall()

for f in farmers:
    email = f[0]

    #  Get Orders, Revenue (Exclude Returned & Cancelled)
    cursor.execute("""
        SELECT 
            COUNT(DISTINCT CASE 
                WHEN o.status NOT IN ('Returned','Cancelled') 
                THEN oi.order_id END) AS total_orders,

            IFNULL(SUM(CASE 
                WHEN o.status NOT IN ('Returned','Cancelled') 
                THEN oi.quantity * oi.price END),0) AS total_revenue,

            COUNT(DISTINCT CASE 
                WHEN o.status = 'Returned' 
                THEN oi.order_id END) AS total_returned_orders

        FROM addproduct ap
        INNER JOIN order_items oi ON ap.id = oi.product_id
        INNER JOIN orders o ON oi.order_id = o.oid
        WHERE ap.email = %s
    """, (email,))
    
    totals = cursor.fetchone()
    total_orders = totals[0] if totals else 0
    total_revenue = totals[1] if totals else 0
    total_returned_orders = totals[2] if totals else 0

    # Insert / Update summary
    cursor.execute("""
        INSERT INTO farmer_sales_summary 
        (email, total_orders, total_revenue, total_returned_orders)
        VALUES (%s, %s, %s, %s)
        ON DUPLICATE KEY UPDATE 
            total_orders=%s, 
            total_revenue=%s,
            total_returned_orders=%s
    """, (
        email, total_orders, total_revenue, total_returned_orders,
        total_orders, total_revenue, total_returned_orders
    ))

    # Chart (Exclude Returned & Cancelled)
    cursor.execute("""
        SELECT p.product_name, IFNULL(SUM(oi.quantity),0) AS total_quantity
        FROM addproduct p
        LEFT JOIN order_items oi ON p.id = oi.product_id
        LEFT JOIN orders o ON oi.order_id = o.oid
        WHERE p.email = %s
        AND (o.status NOT IN ('Returned','Cancelled') OR o.status IS NULL)
        GROUP BY p.product_name
    """, (email,))
    
    data = cursor.fetchall()
    products = [row[0] for row in data]
    quantities = [row[1] for row in data]

    if products:
        plt.figure(figsize=(8,5))
        plt.bar(products, quantities)
        plt.xticks(rotation=45, ha='right')
        plt.xlabel("Product Name")
        plt.ylabel("Total Sold Quantity")
        plt.title(f"Sales Report for {email}")
        plt.tight_layout()

        safe_email = re.sub(r'[^\w\-_\.]', '_', email)
        save_dir = r"C:\Users\yuvas\OneDrive\Desktop\editpro\Farmer (2)\Farmer\web\static"
        os.makedirs(save_dir, exist_ok=True)
        save_path = os.path.join(save_dir, f"farmer_{safe_email}.png")

        plt.savefig(save_path)
        plt.close()

    print(f"Farmer: {email}")
    print(f"  Valid Orders: {total_orders}")
    print(f"  Returned Orders: {total_returned_orders}")
    print(f"  Revenue: ₹{total_revenue}")
    print("-" * 40)

conn.commit()
cursor.close()
conn.close()

print("Returned orders added to summary successfully!")