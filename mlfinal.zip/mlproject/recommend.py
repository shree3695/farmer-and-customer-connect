import mysql.connector
import pandas as pd
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity

# -------------------------
# 1️⃣ Connect to MySQL
# -------------------------
conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="root",
    database="farmer"
)
cursor = conn.cursor()

# -------------------------
# 2️⃣ Fetch user-product-quantity data
# -------------------------
query = """
SELECT o.user_id AS user, p.id AS product_id, p.product_name AS product, oi.quantity
FROM orders o
JOIN order_items oi ON o.oid = oi.order_id
JOIN addproduct p ON oi.product_id = p.id
WHERE o.status IN ('Placed', 'Delivered')
"""
orders = pd.read_sql(query, conn)
print("User-Product Orders:\n", orders.head())

# -------------------------
# 3️⃣ Create user-item matrix
# -------------------------
user_item_matrix = orders.pivot_table(
    index='user',
    columns='product',
    values='quantity',
    aggfunc='sum',
    fill_value=0
)
print("\nUser-Item Matrix:\n", user_item_matrix)

# -------------------------
# 4️⃣ Normalize quantities per user (0–1)
# -------------------------
user_item_matrix_norm = user_item_matrix.div(user_item_matrix.max(axis=1), axis=0).fillna(0)

# -------------------------
# 5️⃣ Compute product similarity
# -------------------------
product_matrix = user_item_matrix_norm.T
similarity = pd.DataFrame(
    cosine_similarity(product_matrix),
    index=product_matrix.index,
    columns=product_matrix.index
)

# -------------------------
# 6️⃣ Recommendation function (weighted)
# -------------------------
def recommend_products(user_id, top_n=4):
    if user_id not in user_item_matrix_norm.index:
        return []
    
    user_ratings = user_item_matrix_norm.loc[user_id]
    purchased = user_ratings[user_ratings > 0].index.tolist()
    
    scores = {}
    for product in user_item_matrix_norm.columns:
        if product in purchased:
            continue
        sim_scores = similarity.loc[product, purchased]
        scores[product] = (sim_scores * user_ratings[purchased]).sum()
    
    recommended = sorted(scores.items(), key=lambda x: x[1], reverse=True)
    return recommended[:top_n]

# -------------------------
# 7️⃣ Clear old recommendations
# -------------------------
cursor.execute("DELETE FROM user_recommendations")
conn.commit()

# -------------------------
# 8️⃣ Generate & insert new recommendations
# -------------------------
for user_id in user_item_matrix_norm.index:
    recs = recommend_products(user_id, top_n=4)
    for product_name, score in recs:
        # Get product_id from orders DataFrame
        product_id = int(orders[orders['product'] == product_name]['product_id'].iloc[0])
        cursor.execute(
            "INSERT INTO user_recommendations (uid, product_id, score) VALUES (%s,%s,%s)",
            (int(user_id), product_id, float(score))  # ✅ Convert to native Python types
        )

conn.commit()

# -------------------------
# 9️⃣ Print top recommendations for verification
# -------------------------
for user_id in user_item_matrix_norm.index:
    recs = recommend_products(user_id, top_n=4)
    print(f"\nTop recommendations for User {user_id}:")
    if not recs:
        print("  No recommendations available (user has no purchases).")
    else:
        for product, score in recs:
            print(f"  {product}: {score:.2f}")

# -------------------------
# 🔟 Close connection
# -------------------------
conn.close()
