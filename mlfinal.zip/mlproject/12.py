import sys
import mysql.connector
import matplotlib.pyplot as plt
import os
import re

# -----------------------------
# 1️⃣ Get farmer email safely
# -----------------------------
if len(sys.argv) < 2:
    print("Error: No farmer email provided!")
    sys.exit(1)

farmer_email = sys.argv[1]
print(f"Generating chart for farmer: {farmer_email}")

# -----------------------------
# 2️⃣ Connect to database
# -----------------------------
try:
    conn = mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database="farmer"
    )
except mysql.connector.Error as e:
    print(f"Database connection error: {e}")
    sys.exit(1)

cursor = conn.cursor()

# -----------------------------
# 3️⃣ Fetch product sales for this farmer (chart)
# -----------------------------
query = """
SELECT p.product_name, IFNULL(SUM(oi.quantity),0) AS total_quantity
FROM addproduct p
LEFT JOIN order_items oi ON p.id = oi.product_id
WHERE p.email = %s
GROUP BY p.product_name
"""

cursor.execute(query, (farmer_email,))
data = cursor.fetchall()

if not data:
    print("No products found for this farmer!")
    products = []
    quantities = []
else:
    products = [row[0] for row in data]
    quantities = [row[1] for row in data]

# -----------------------------
# 4️⃣ Calculate total orders and total revenue
# -----------------------------
totals_query = """
SELECT 
    COUNT(DISTINCT oi.order_id) AS total_orders,
    IFNULL(SUM(oi.quantity * oi.price),0) AS total_revenue
FROM addproduct ap
INNER JOIN order_items oi ON ap.id = oi.product_id
INNER JOIN orders o ON oi.order_id = o.oid
WHERE ap.email = %s
"""
cursor.execute(totals_query, (farmer_email,))
totals = cursor.fetchone()
total_orders = totals[0] if totals else 0
total_revenue = totals[1] if totals else 0

# 🔹 Print totals so JSP can read them
print(f"Total Orders: {total_orders}")
print(f"Total Revenue: ₹{total_revenue}")

# Close DB connection
cursor.close()
conn.close()

# -----------------------------
# 5️⃣ Generate unique chart filename
# -----------------------------
safe_email = re.sub(r'[^\w\-_\.]', '_', farmer_email)
save_path = fr"C:\Users\yuvas\OneDrive\Desktop\editpro\Farmer (2)\Farmer\web\static\farmer_{safe_email}.png"

# -----------------------------
# 6️⃣ Generate chart
# -----------------------------
if products:
    plt.figure(figsize=(8,5))
    plt.bar(products, quantities, color='skyblue')
    plt.xticks(rotation=45, ha='right')
    plt.xlabel("Product Name")
    plt.ylabel("Total Sold Quantity")
    plt.title(f"Sales Report for {farmer_email}")
    plt.tight_layout()
    plt.savefig(save_path)
    plt.close()
    print(f"Chart generated successfully: {save_path}")
else:
    print("No data to plot. Chart not generated.")
